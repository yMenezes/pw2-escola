package br.com.etechoracio.pw2escola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw2EscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}

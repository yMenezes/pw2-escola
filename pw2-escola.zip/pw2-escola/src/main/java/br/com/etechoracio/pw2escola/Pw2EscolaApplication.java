package br.com.etechoracio.pw2escola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw2EscolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw2EscolaApplication.class, args);
	}

}
